package org.sfu.p2startercode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P2StarterCodeApplicationTests {

    @Test
    void contextLoads() {
    }

}
