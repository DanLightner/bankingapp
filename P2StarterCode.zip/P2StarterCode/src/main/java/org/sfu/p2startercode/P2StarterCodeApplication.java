package org.sfu.p2startercode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P2StarterCodeApplication {

    public static void main(String[] args) {
        SpringApplication.run(P2StarterCodeApplication.class, args);
    }

}
