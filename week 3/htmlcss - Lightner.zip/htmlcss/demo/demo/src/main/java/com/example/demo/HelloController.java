package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HelloController {
    //note: overwrote the getmapping for the hello world demo
    @GetMapping("/htmlHomework")
    public String getHtmlHomework() {
        return "forward:/Week3Homework.html";
    }

}
